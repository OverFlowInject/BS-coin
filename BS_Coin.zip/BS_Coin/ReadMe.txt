
###########################################################################################################
                                                                                                           
                                                                                                           
BBBBBBBBBBBBBBBBB      SSSSSSSSSSSSSSS              CCCCCCCCCCCCC                   iiii                   
B::::::::::::::::B   SS:::::::::::::::S          CCC::::::::::::C                  i::::i                  
B::::::BBBBBB:::::B S:::::SSSSSS::::::S        CC:::::::::::::::C                   iiii                   
BB:::::B     B:::::BS:::::S     SSSSSSS       C:::::CCCCCCCC::::C                                          
  B::::B     B:::::BS:::::S                  C:::::C       CCCCCC   ooooooooooo   iiiiiiinnnn  nnnnnnnn    
  B::::B     B:::::BS:::::S                 C:::::C               oo:::::::::::oo i:::::in:::nn::::::::nn  
  B::::BBBBBB:::::B  S::::SSSS              C:::::C              o:::::::::::::::o i::::in::::::::::::::nn 
  B:::::::::::::BB    SS::::::SSSSS         C:::::C              o:::::ooooo:::::o i::::inn:::::::::::::::n
  B::::BBBBBB:::::B     SSS::::::::SS       C:::::C              o::::o     o::::o i::::i  n:::::nnnn:::::n
  B::::B     B:::::B       SSSSSS::::S      C:::::C              o::::o     o::::o i::::i  n::::n    n::::n
  B::::B     B:::::B            S:::::S     C:::::C              o::::o     o::::o i::::i  n::::n    n::::n
  B::::B     B:::::B            S:::::S      C:::::C       CCCCCCo::::o     o::::o i::::i  n::::n    n::::n
BB:::::BBBBBB::::::BSSSSSSS     S:::::S       C:::::CCCCCCCC::::Co:::::ooooo:::::oi::::::i n::::n    n::::n
B:::::::::::::::::B S::::::SSSSSS:::::S        CC:::::::::::::::Co:::::::::::::::oi::::::i n::::n    n::::n
B:BY OLIVER::::::B  S::::DEAKIN:::::SS           CCC::::::::::::C oo:::::::::::oo i::::::i n::::n    n::::n
BBBBBBBBBBBBBBBBB    SSSSSSSSSSSSSSS                CCCCCCCCCCCCC   ooooooooooo   iiiiiiii nnnnnn    nnnnnn
                                                                                                           
                                                                                                                                                                                                                     
                                                                                                           
#############################################################################################################   

BS coin is a in-dev digital currency that uses secure USB transactions to send data/*BSC to your friends, family or
your other accounts we are setting up a server as you read this to make the transaction even more secure. 
thanks for using BS coin.
(fantasy digital currency used for trading with friends [This is not a real crypto currency **yet])                                                                                                        
                                                                                                           
"Misc" is full of features and older version that got too buggy to uses but we keep them for future 
development.

"Experimental" folder is full of features that we will be adding soon. try theses at your own risk 
they may modify the "Main apps".

"Main apps" are the apps that you will uses to trade, check your balance or create your account
we are in alpha at the moment so expect bugs.

HOW TO USE:
1: open "Main apps" folder and click on the python document named "BS_COIN_V2.py".
2: run the program in a python interpreter/IDLE (We recommend IDLE or Mue)
3: onces the program run follow the text on screen
4: if the program does not open when you select one of the apps you need
to install python as a dir with cmd find more info online. Or you may need
to click on it the programs manualy 


Latest news: Soon we will be switching to an online server
so you dont have to have your amount stored on your computer,
To make it more secure for you and your family.

version : BS_COIN_V2 
python version : 3.9 or 3.10 (64-bit)
made by : Oliver Deakin 

*short for BS coin
**we might soon turn this into a real crypto currency
