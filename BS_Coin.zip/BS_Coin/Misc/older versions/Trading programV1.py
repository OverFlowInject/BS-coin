import os
import socket

# Define the USB drive path
usb_drive_path = "yes"

hostname = socket.gethostname()
ip_address = socket.gethostbyname(hostname)
# # # # # # # 
message = input("Enter how much you want to give: ")
ipname = input("what is the recivers ip: ")
usb_drive_path = input("what is the file path (where the file is ): ")
balancename = ip_address + ".txt"

with open(balancename, "a+") as file:
    number_string = file.read().strip() # read the file contents and remove any leading/trailing white space
    number = int(number_string)  # convert the string to an integer

    if number < message:
        print("sorry you do not have that amount")
        print("re-open the program and start again")
        print(" (this is for security reasons) ")
        quit()
        
    file.close()
    
    
# Define the filename for the text file
filename = ipname + ".txt"

# Define the full path for the text file
file_path = os.path.join(usb_drive_path, filename)

# Write the message to the text file
  

# Prompt the user to confirm if the recipient has received the message
while True:
    response = input("Has the recipient received the message? (y/n)")

    if response.lower() == "y":
        print("Message delivered successfully.")
        with open(balancename, "a+") as file:
            number_string = file.read().strip()  # read the file contents and remove any leading/trailing white space
            number = int(number_string)  # convert the string to an integer
            new_amountInt = number - message
            new_amount = str(new_amountInt)
            file.write(new_amount)
            
        
            file.close()
        with open(file_path, "a+") as file:
            number_string = file.read().strip()  # read the file contents and remove any leading/trailing white space
            number = int(number_string)  # convert the string to an integer
            new_amountInt = number + message
            new_amount = str(new_amountInt)
            file.write(new_amount)
            file.close
            
        break
    elif response.lower() == "n":
        print("Please try again later.")
        break
    else:
        print("Invalid response. Please enter 'y' or 'n'.")

# Print a confirmation message
print("Message saved to USB drive.")
