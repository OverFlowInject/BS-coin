import os
import socket

# Define the USB drive path
usb_drive_path = "yes"

# Get the hostname and IP address of the sender
hostname = socket.gethostname()
ip_address = socket.gethostbyname(hostname)

# Prompt the user for the message amount, recipient's IP address, and file path
message = int(input("Enter how much you want to give: "))
ipname = input("What is the recipient's IP address: ")
file_path = input("What is the file path (where the file is located): ")

# Define the filename for the balance text file
balancename = ip_address + ".txt"

# Check if the balance file exists and is not empty
if os.path.exists(balancename) and os.path.getsize(balancename) > 0:
    # Open the balance file and read its contents
    with open(balancename, "r") as file:
        number_string = file.read().strip()  # read the file contents and remove any leading/trailing white space
        number = int(number_string)  # convert the string to an integer
else:
    # If the file doesn't exist or is empty, set the balance to 0
    number = 0

# Check if the sender has sufficient balance to send the message amount
if number < message:
    print("Sorry, you do not have enough balance to send this message.")
    print("Please try again later.")
    quit()

# Deduct the message amount from the sender's balance
number -= message

# Write the new balance to the sender's balance file
with open(balancename, "w") as file:
    file.write(str(number))

# Add the message amount to the recipient's balance
filename = ipname + ".txt"
recipient_balance_file = os.path.join(file_path, filename)
if os.path.exists(recipient_balance_file) and os.path.getsize(recipient_balance_file) > 0:
    with open(recipient_balance_file, "r") as file:
        number_string = file.read().strip()  # read the file contents and remove any leading/trailing white space
        number = int(number_string)  # convert the string to an integer
else:
    number = 0

number += message

with open(recipient_balance_file, "w") as file:
    file.write(str(number))

# Prompt the user to confirm if the recipient has received the message
while True:
    response = input("Has the recipient received the message? (y/n)")

    if response.lower() == "y":
        print("Message delivered successfully.")
        break
    elif response.lower() == "n":
        print("Please try again later.")
        break
    else:
        print("Invalid response. Please enter 'y' or 'n'.")

# Print a confirmation message
print("Message saved to USB drive.")
