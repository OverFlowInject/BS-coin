import socket

hostname = socket.gethostname()
ip_address = socket.gethostbyname(hostname)

class ATM:
    def __init__(self, file_name):
        self.file_name = file_name

    def check_balance(self):
        with open(self.file_name, 'r') as file:
            number_string = file.read().strip()  # read the file contents and remove any leading/trailing white space
            balance = int(number_string)  # convert the string to an integer
        return balance

    def deposit(self, amount):
        with open(self.file_name, 'r') as f:
            balance = float(f.read())
        balance += amount

atm = ATM(ip_address + '.txt')
print(f"Your balance is: ${atm.check_balance():.2f}")

#work in progres
'''
with open('balance.txt', 'r') as file:
    number_string = file.read().strip()  # read the file contents and remove any leading/trailing white space
    number = int(number_string)  # convert the string to an integer
'''
