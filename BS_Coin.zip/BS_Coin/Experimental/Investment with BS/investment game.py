import random

class Stock:
    def __init__(self, symbol, name, price):
        self.symbol = symbol
        self.name = name
        self.price = price

    def update_price(self):
        self.price *= random.uniform(0.9, 1.1)


class Market:
    def __init__(self, stocks):
        self.stocks = stocks

    def update_prices(self):
        for stock in self.stocks:
            stock.update_price()


class Portfolio:
    def __init__(self):
        self.stocks = {}

    def buy(self, stock, quantity):
        if stock.symbol in self.stocks:
            self.stocks[stock.symbol] += quantity
        else:
            self.stocks[stock.symbol] = quantity

    def sell(self, stock, quantity):
        if stock.symbol in self.stocks:
            if self.stocks[stock.symbol] >= quantity:
                self.stocks[stock.symbol] -= quantity
                return True
            else:
                return False
        else:
            return False


class Game:
    def __init__(self):
        stocks = [
            Stock("AAPL", "Apple Inc.", 125.12),
            Stock("AMZN", "Amazon.com Inc.", 3116.85),
            Stock("GOOGL", "Alphabet Inc.", 1997.59),
            Stock("FB", "Meta Platforms Inc.", 320.18),
            Stock("MSFT", "Microsoft Corporation", 231.60),
        ]
        self.market = Market(stocks)
        self.portfolio = Portfolio()

    def buy_stock(self, symbol, quantity):
        stock = self.find_stock(symbol)
        if stock is None:
            print("Invalid symbol. Please try again.")
        else:
            cost = stock.price * quantity
            if cost > self.get_balance():
                print("Insufficient balance.")
            else:
                self.portfolio.buy(stock, quantity)
                print(f"Bought {quantity} shares of {stock.symbol} at ${stock.price:.2f} per share.")

    def sell_stock(self, symbol, quantity):
        stock = self.find_stock(symbol)
        if stock is None:
            print("Invalid symbol. Please try again.")
        elif not self.portfolio.sell(stock, quantity):
            print("Invalid quantity. Please try again.")
        else:
            sale_price = stock.price * quantity
            self.portfolio.sell(stock, quantity)
            print(f"Sold {quantity} shares of {stock.symbol} at ${stock.price:.2f} per share.")

    def find_stock(self, symbol):
        for stock in self.market.stocks:
            if stock.symbol == symbol:
                return stock
        return None

    def get_balance(self):
        total_value = 0
        for symbol, quantity in self.portfolio.stocks.items():
            stock = self.find_stock(symbol)
            total_value += stock.price * quantity
        return 10000 - total_value

    def run(self):
        print("Welcome to the investment game!")
        while True:
            self.market.update_prices()
            print("\nCurrent prices:")
            for stock in self.market.stocks:
                print(f"{stock.symbol} - {stock.name}: ${stock.price:.2f}")
            print(f"\nYour balance: ${self.get_balance():.2f}")
            action = input("What would you like to do? (buy/sell/quit) ")
            if action == "buy":
                symbol = input("Enter the stock symbol: ")
                quantity = int(input("Enter the quantity: "))
                self.buy_stock(symbol, quantity)
            elif action == "sell":
                symbol = input("what")
